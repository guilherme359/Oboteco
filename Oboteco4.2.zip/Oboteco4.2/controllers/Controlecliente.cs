﻿




using Oboteco.models;
using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Oboteco.controllers
{
    public class Controlecliente
    {
        
        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Oboteco4.2\\DbBoteco.mdf;Integrated Security=True");
        clientes cliente = new clientes();
        

        public bool inserirClientes(string nome, string celular, string email, string data_nascimento)
        {
            try
            {
               
                
                    if (con.State == ConnectionState.Open)
                    {
                        con.Close();
                    }


                string sql = "INSERT INTO Clientes(nome, celular, email, data_nascimento) VALUES ('" + nome + "', '" + celular + "', '" + email + "', '" + data_nascimento + "')";
                SqlCommand cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                return true;
                
            }catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public void ExcluirCliente(string id)    
        {

            try
            {


                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }


                string sql = "DELETE FROM clientes WHERE id = " + id;
                SqlCommand cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("USUARIO EXCLUIDO");
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                
            }
        }
        public bool EditarCliente(string id, string nome, string celular, string email, string data_nascimento)
        {
            try
            {


                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }


                string sql = "UPDATE clientes SET nome ='" + nome + "', celular ='" + celular + "',email = '" + email + "', data_nascimento = '" + data_nascimento + "' WHERE id = "+id+"";
                SqlCommand cmd = new SqlCommand(sql, con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                return true;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
        public List<string> LocalizarCliente(string id)
        {
            try
            {
                if (con.State == ConnectionState.Open) con.Close();
                string sql = $"SELECT nome, celular, email, data_nascimento FROM clientes WHERE Id = {id}";
                SqlCommand cmd = new SqlCommand(sql, con);
                con.Open();
                List<string> cli = new List<string>();
                cmd.ExecuteNonQuery();
                SqlDataReader dr = cmd.ExecuteReader();
                clientes clientes = new clientes();
                if (dr.Read())
                {
                    if (dr.Read())
                    {
                        cliente.nome = (string)dr["nome"];
                        cliente.celular = (string)dr["celular"];
                        cliente.email = (string)dr["email"];
                        string data = (string)dr["data_nascimento"];
                        cli.Add(cliente.nome);
                        cli.Add(cliente.celular);
                        cli.Add(cliente.email);
                        cli.Add(data);
                    }
                }
                return cli;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro inesperado: " + ex.Message);
                return null;
            }
        }
        public List<clientes> Listar(List<clientes> lista) 
        {
            lista = new List<clientes>();
            
            if (con.State == ConnectionState.Open)
            { 
                con.Close(); 
            }
            string sql = "SELECT * FROM clientes";
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            cmd.ExecuteNonQuery();
            SqlDataReader dr = cmd.ExecuteReader();
            

            while (dr.Read())
            {
                clientes clientes = new clientes();
                clientes.id = (int)dr["id"];
                clientes.email = (string)dr["email"];
                clientes.nome = (string)dr["nome"];
                clientes.celular = dr["celular"].ToString();
                clientes.data_nascimento = (DateTime)dr["data_nascimento"];
                lista.Add(clientes);
            }
            con.Close();
            dr.Close();
            return lista;

        }
         
        
    }
    
}