﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Oboteco
{
    public partial class frmprincipal : Form
    {
        public frmprincipal()
        {
            InitializeComponent();
        }
        private void AtualizarDashboard()
        {
            AtualizarTotalDia();
            AtualizarVendasAbertas();
        }

        private void AtualizarTotalDia()
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Aluno\\Desktop\\Oboteco4.2\\DbBoteco.mdf;Integrated Security=True";
            decimal totalVendido = 0;
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("TotalFechadoDia", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        var resultado = cmd.ExecuteScalar();
                        if (resultado != null && resultado != DBNull.Value)
                        {
                            totalVendido = Convert.ToDecimal(resultado);
                        }
                    }
                }
                lblTotalDia.Text = totalVendido.ToString("C2", CultureInfo.GetCultureInfo("pt-BR"));
            }
            catch (Exception ex)
            {
                lblTotalDia.Text = "Erro";
            }
        }

        private void AtualizarVendasAbertas()
        {
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Aluno\\Desktop\\Oboteco4.2\\DbBoteco.mdf;Integrated Security=True";
            lsvAbertas.BeginUpdate();
            lsvAbertas.Items.Clear();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("VendasAbertasDia", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        con.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string idVenda = reader["Id"].ToString();
                                string nomeCliente = reader["NomeCliente"].ToString();
                                decimal valorTotal = Convert.ToDecimal(reader["total"]);
                                ListViewItem item = new ListViewItem(idVenda);
                                item.SubItems.Add(nomeCliente);
                                item.SubItems.Add(valorTotal.ToString("C2", CultureInfo.GetCultureInfo("pt-BR")));
                                item.Tag = (int)reader["Id"];
                                lsvAbertas.Items.Add(item);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                lsvAbertas.EndUpdate();
            }
        }







        private void sAIRToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var a = MessageBox.Show("Deseja realmente sair?", "confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (a == DialogResult.Yes)
            {
                Environment.Exit(0);
            }
        }

        private void vENDASToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frmvendas venda = new Frmvendas();
            venda.Show();
        }

        private void cADASTROSToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void cLIENTESToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmcliente cliente = new frmcliente();
            cliente.Show();
        }

        private void fUNCIONARIOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frmfuncionario funcionario = new Frmfuncionario();
            funcionario.Show();
        }

        private void pRODUTOSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frmproduto produto = new Frmproduto();
            produto.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            frmcliente cliente = new frmcliente();
            cliente.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Frmfuncionario funcionario = new Frmfuncionario();
            funcionario.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Frmproduto produto = new Frmproduto();
            produto.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Frmvendas venda = new Frmvendas();
            venda.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            var a = MessageBox.Show("Deseja realmente sair?", "confirmação", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (a == DialogResult.Yes)
            {
                Environment.Exit(0);
            }
        }

        private void frmprincipal_Load(object sender, EventArgs e)
        {
            AtualizarDashboard();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            AtualizarDashboard();
        }


        private void lsvAbertas_ItemActivate(object sender, EventArgs e)
        {
            if (lsvAbertas.SelectedItems.Count > 0)
            {
                ListViewItem itemSelecionado = lsvAbertas.SelectedItems[0];
                int idVendaParaAbrir = (int)itemSelecionado.Tag;
                timer1.Stop();
                using (Frmvendas formularioVenda = new Frmvendas())
                {
                    formularioVenda.CarregarVenda(idVendaParaAbrir);
                    formularioVenda.ShowDialog();
                }
                AtualizarDashboard();
                timer1.Start();
            }
        }
    }
}
