﻿namespace Oboteco
{
    partial class frmlogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtlogin = new TextBox();
            label1 = new Label();
            label2 = new Label();
            txtsenha = new TextBox();
            btnlogin = new Button();
            btncancelar = new Button();
            SuspendLayout();
            // 
            // txtlogin
            // 
            txtlogin.Location = new Point(11, 41);
            txtlogin.Name = "txtlogin";
            txtlogin.Size = new Size(412, 23);
            txtlogin.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(11, 18);
            label1.Name = "label1";
            label1.Size = new Size(56, 20);
            label1.TabIndex = 1;
            label1.Text = "LOGIN";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(11, 82);
            label2.Name = "label2";
            label2.Size = new Size(59, 20);
            label2.TabIndex = 4;
            label2.Text = "SENHA";
            // 
            // txtsenha
            // 
            txtsenha.Location = new Point(11, 105);
            txtsenha.Name = "txtsenha";
            txtsenha.Size = new Size(412, 23);
            txtsenha.TabIndex = 3;
            // 
            // btnlogin
            // 
            btnlogin.BackColor = Color.LimeGreen;
            btnlogin.FlatStyle = FlatStyle.Flat;
            btnlogin.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnlogin.Location = new Point(72, 164);
            btnlogin.Name = "btnlogin";
            btnlogin.Size = new Size(109, 41);
            btnlogin.TabIndex = 5;
            btnlogin.Text = "LOGIN";
            btnlogin.UseVisualStyleBackColor = false;
            btnlogin.Click += button1_Click;
            // 
            // btncancelar
            // 
            btncancelar.BackColor = Color.Crimson;
            btncancelar.FlatStyle = FlatStyle.Flat;
            btncancelar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btncancelar.Location = new Point(243, 164);
            btncancelar.Name = "btncancelar";
            btncancelar.Size = new Size(109, 41);
            btncancelar.TabIndex = 6;
            btncancelar.Text = "CANCELAR";
            btncancelar.UseVisualStyleBackColor = false;
            btncancelar.Click += button2_Click;
            // 
            // frmlogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightCyan;
            ClientSize = new Size(435, 217);
            Controls.Add(btncancelar);
            Controls.Add(btnlogin);
            Controls.Add(label2);
            Controls.Add(txtsenha);
            Controls.Add(label1);
            Controls.Add(txtlogin);
            FormBorderStyle = FormBorderStyle.None;
            Name = "frmlogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "login";
            Load += frmlogin_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtlogin;
        private Label label1;
        private Label label2;
        private TextBox txtsenha;
        private Button btnlogin;
        private Button btncancelar;
    }
}