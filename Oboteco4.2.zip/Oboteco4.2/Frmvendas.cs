﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace Oboteco
{
    public partial class Frmvendas : Form
    {

        SqlConnection con = new SqlConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Aluno\\Desktop\\Oboteco4.2\\DbBoteco.mdf;Integrated Security=True");


        public Frmvendas()
        {
            InitializeComponent();
        }


        public void CarregarVenda(int idVenda)
        {
            // Sua string de conexão
            string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Programas\\OBoteco\\OBoteco\\DbBoteco.mdf;Integrated Security=True";
            dgvpedido.Columns.Clear();
            dgvpedido.Columns.Add("ID", "ID");
            dgvpedido.Columns.Add("Produto", "Produto");
            dgvpedido.Columns.Add("Quantidade", "Quantidade");
            dgvpedido.Columns.Add("Valor Unitário", "Valor Unitário");
            dgvpedido.Columns.Add("Total", "Total");
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    using (SqlCommand cmd = new SqlCommand("LocalizarVendido", con))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Id", idVenda);
                        con.Open();
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            bool vendaCarregada = false;
                            dgvpedido.Rows.Clear();
                            while (reader.Read())
                            {
                                if (!vendaCarregada)
                                {
                                    txtidvenda.Text = reader["Id"].ToString();
                                    cbxcliente.Text = reader["nomecliente"].ToString();
                                    decimal total = Convert.ToDecimal(reader["total"]);
                                    txttotal.Text = total.ToString("C2", CultureInfo.GetCultureInfo("pt-BR"));
                                    vendaCarregada = true;
                                    cbxcliente.Enabled = true;
                                    cbxproduto.Enabled = true;
                                    CarregaCbxCliente();
                                    CarregaCbxProduto();
                                    txtidproduto.Enabled = true;
                                    txtquantidade.Enabled = true;
                                    txtvalor.Enabled = true;
                                    txttotal.Enabled = true;
                                    btnatualizarpedido.Enabled = true;
                                    btnfinalizarpedido.Enabled = true;
                                    btnfinalizarvenda.Enabled = true;
                                    btnnovoitem.Enabled = true;
                                    btneditaritem.Enabled = true;
                                    btnexcluiritem.Enabled = true;
                                }
                                dgvpedido.Rows.Add(
                                    reader["id_produto"],
                                    reader["nomeproduto"],
                                    reader["quantidade"],
                                    Convert.ToDecimal(reader["preco"]),
                                    Convert.ToDecimal(reader["subtotal"])
                                );
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao carregar a venda: " + ex.Message);
            }
        }

        private void btnvoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void CarregaCbxCliente()
        {
            string cli = "SELECT * FROM Clientes";
            SqlCommand cmd = new SqlCommand(cli, con);
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(cli, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "clientes");
            cbxcliente.ValueMember = "Id";
            cbxcliente.DisplayMember = "nome";
            cbxcliente.DataSource = ds.Tables["clientes"];
            con.Close();
        }
       

        public void CarregaCbxProduto()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            string pro = "SELECT * FROM Produto";
            SqlCommand cmd = new SqlCommand(pro, con);
            con.Open();
            cmd.CommandType = CommandType.Text;
            SqlDataAdapter da = new SqlDataAdapter(pro, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "produto");
            cbxproduto.ValueMember = "Id";
            cbxproduto.DisplayMember = "nome";
            cbxproduto.DataSource = ds.Tables["produto"];
            con.Close();
        }


        private void Frmvendas_Load(object sender, EventArgs e)
        {
            cbxcliente.Enabled = false;
            cbxproduto.Enabled = false;
            txtidproduto.Enabled = false;
            txtquantidade.Enabled = false;
            txtvalor.Enabled = false;
            txttotal.Enabled = false;
            btnatualizarpedido.Enabled = false;
            btnfinalizarpedido.Enabled = false;
            btnnovoitem.Enabled = false;
            btneditaritem.Enabled = false;
            btnexcluiritem.Enabled = false;
        }


        private void btnnovopedido_Click(object sender, EventArgs e)
        {
            cbxcliente.Enabled = true;
            cbxproduto.Enabled = true;
            CarregaCbxCliente();
            CarregaCbxProduto();
            txtidproduto.Enabled = true;
            txtquantidade.Enabled = true;
            txtvalor.Enabled = true;
            txttotal.Enabled = true;
            btnatualizarpedido.Enabled = true;
            btnfinalizarpedido.Enabled = true;
            btnfinalizarvenda.Enabled = true;
            btnnovoitem.Enabled = true;
            btneditaritem.Enabled = true;
            btnexcluiritem.Enabled = true;
            dgvpedido.Columns.Add("ID", "ID");
            dgvpedido.Columns.Add("Produto", "Produto");
            dgvpedido.Columns.Add("Quantidade", "Quantidade");
            dgvpedido.Columns.Add("Valor Unitário", "Valor Unitário");
            dgvpedido.Columns.Add("Total", "Total");
        }

        private void cbxproduto_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            SqlCommand cmd = new SqlCommand("SELECT * FROM Produto WHERE Id=@Id", con);
            cmd.Parameters.AddWithValue("@Id", cbxproduto.SelectedValue);
            cmd.CommandType = CommandType.Text;
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                txtvalor.Text = dr["preco"].ToString();
                txtidproduto.Text = dr["Id"].ToString();
                txtestoque.Text = dr["quantidade"].ToString();
                txtquantidade.Focus();
                dr.Close();
            }
            con.Close();
        }

        private void btnnovoitem_Click(object sender, EventArgs e)
        {
            var repetido = false;
            foreach (DataGridViewRow dr in dgvpedido.Rows)
            {
                if (txtidproduto.Text == Convert.ToString(dr.Cells[0].Value))
                {
                    repetido = true;
                }
            }
            if (repetido == false)
            {
                DataGridViewRow item = new DataGridViewRow();
                item.CreateCells(dgvpedido);
                item.Cells[0].Value = txtidproduto.Text;
                item.Cells[1].Value = cbxproduto.Text;
                item.Cells[2].Value = txtquantidade.Text;
                item.Cells[3].Value = txtvalor.Text;
                item.Cells[4].Value = Convert.ToDecimal(txtquantidade.Text) * Convert.ToDecimal(txtvalor.Text);
                dgvpedido.Rows.Add(item);
                txtidproduto.Text = string.Empty;
                txtquantidade.Text = string.Empty;
                cbxproduto.Text = string.Empty;
                txtvalor.Text = string.Empty;
                txtestoque.Text = string.Empty;
                decimal soma = 0;
                foreach (DataGridViewRow dr in dgvpedido.Rows)
                    soma += Convert.ToDecimal(dr.Cells[4].Value);
                txttotal.Text = Convert.ToString(soma);
            }
            else
            {
                MessageBox.Show("Produto já adicionado ao pedido!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void dgvpedido_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dgvpedido.Rows[e.RowIndex];
            txtidproduto.Text = Convert.ToString(row.Cells[0].Value);
            cbxproduto.Text = Convert.ToString(row.Cells[1].Value);
            txtquantidade.Text = Convert.ToString(row.Cells[2].Value);
            txtvalor.Text = Convert.ToString(row.Cells[3].Value);
        }

        private void btneditaritem_Click(object sender, EventArgs e)
        {
            int linha = dgvpedido.CurrentRow.Index;
            dgvpedido.Rows[linha].Selected = true;
            dgvpedido.Rows[linha].Cells[0].Value = txtidproduto.Text;
            dgvpedido.Rows[linha].Cells[1].Value = cbxproduto.Text;
            dgvpedido.Rows[linha].Cells[2].Value = txtquantidade.Text;
            dgvpedido.Rows[linha].Cells[3].Value = txtvalor.Text;
            dgvpedido.Rows[linha].Cells[4].Value = Convert.ToDecimal(txtquantidade.Text) * Convert.ToDecimal(txtvalor.Text);
            txtidproduto.Text = string.Empty;
            txtquantidade.Text = string.Empty;
            cbxproduto.Text = string.Empty;
            txtvalor.Text = string.Empty;
            txtestoque.Text = string.Empty;
            decimal soma = 0;
            foreach (DataGridViewRow dr in dgvpedido.Rows)
                soma += Convert.ToDecimal(dr.Cells[4].Value);
            txttotal.Text = Convert.ToString(soma);
        }

        private void btnexcluiritem_Click(object sender, EventArgs e)
        {
            int linha = dgvpedido.CurrentRow.Index;
            dgvpedido.Rows.RemoveAt(linha);
            dgvpedido.Refresh();
            txtidproduto.Text = string.Empty;
            txtquantidade.Text = string.Empty;
            cbxproduto.Text = string.Empty;
            txtvalor.Text = string.Empty;
            txtestoque.Text = string.Empty;
            decimal soma = 0;
            foreach (DataGridViewRow dr in dgvpedido.Rows)
                soma += Convert.ToDecimal(dr.Cells[4].Value);
            txttotal.Text = Convert.ToString(soma);
        }
        private void txtquantidade_Leave(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("Quantidade_produto", con);
            cmd.Parameters.AddWithValue("@Id", txtidproduto.Text);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataReader dr = cmd.ExecuteReader();
            int valor1 = 0;
            bool conversaoSucedida = int.TryParse(txtquantidade.Text, out valor1);
            if (dr.Read())
            {
                int valor2 = Convert.ToInt32(dr["quantidade"].ToString());
                if (valor1 > valor2)
                {
                    MessageBox.Show("Não tem a quantidade suficiente para venda!", "Estoque Insuficiente", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtquantidade.Text = string.Empty;
                    txtquantidade.Focus();
                }
            }
            con.Close();
        }
        private void btnfinalizarpedido_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("InserirVenda", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id_cliente", cbxcliente.SelectedValue);
            cmd.Parameters.AddWithValue("@total", Convert.ToDecimal(txttotal.Text));
            cmd.Parameters.AddWithValue("@data_venda", SqlDbType.DateTime).Value = DateTime.Today;
            cmd.Parameters.AddWithValue("@situacao", SqlDbType.NChar).Value = "Aberta";
            cmd.ExecuteNonQuery();
            string idvenda = "SELECT IDENT_CURRENT('Venda') AS id_venda";
            SqlCommand cmd2 = new SqlCommand(idvenda, con);
            Int32 idvenda2 = Convert.ToInt32(cmd2.ExecuteScalar());
            foreach (DataGridViewRow dr in dgvpedido.Rows)
            {
                SqlCommand cmd3 = new SqlCommand("InserirItensVendidos", con);
                cmd3.CommandType = CommandType.StoredProcedure;
                cmd3.Parameters.AddWithValue("@id_venda", idvenda2);
                cmd3.Parameters.AddWithValue("@id_produto", Convert.ToInt32(dr.Cells[0].Value));
                cmd3.Parameters.AddWithValue("@quantidade", Convert.ToInt32(dr.Cells[2].Value));
                cmd3.Parameters.AddWithValue("@preco", Convert.ToDecimal(dr.Cells[3].Value));
                cmd3.Parameters.AddWithValue("@subtotal", Convert.ToDecimal(dr.Cells[4].Value));
                cmd3.ExecuteNonQuery();
                SqlCommand cmd4 = new SqlCommand("AtualizaEstoqueVenda", con);
                cmd4.CommandType = CommandType.StoredProcedure;
                cmd4.Parameters.AddWithValue("@id_produto", Convert.ToInt32(dr.Cells[0].Value));
                cmd4.Parameters.AddWithValue("@quantidade", Convert.ToInt32(dr.Cells[2].Value));
                cmd4.ExecuteNonQuery();
            }
            con.Close();
            dgvpedido.Rows.Clear();
            dgvpedido.Refresh();
            txttotal.Text = string.Empty;
            txtvalor.Text = string.Empty;
            txtquantidade.Text = string.Empty;
            txtidproduto.Text = string.Empty;
            cbxproduto.Text = string.Empty;
            cbxcliente.Text = string.Empty;
            cbxcliente.Enabled = false;
            cbxproduto.Enabled = false;
            txtidproduto.Enabled = false;
            txtquantidade.Enabled = false;
            txtvalor.Enabled = false;
            txttotal.Enabled = false;
            btnatualizarpedido.Enabled = false;
            btnfinalizarpedido.Enabled = false;
            btnnovoitem.Enabled = false;
            btneditaritem.Enabled = false;
            btnexcluiritem.Enabled = false;
            MessageBox.Show("Pedido finalizado com sucesso!", "Sucesso", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void btnlocalizar_Click(object sender, EventArgs e)
        {
            dgvpedido.Columns.Clear();
            dgvpedido.Rows.Clear();
            con.Open();
            try
            {
                SqlCommand cmd = new SqlCommand("VendaId", con);
                cmd.Parameters.AddWithValue("@Id", SqlDbType.Int).Value = Convert.ToInt32(txtidvenda.Text.Trim());
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);
                string venda = dt.Rows[0]["situacao"].ToString().Trim();
                int linhas = dt.Rows.Count;
                if (dt.Rows.Count > 0 && venda == "Aberta")
                {
                    con.Close();
                    con.Open();
                    SqlCommand pedido = new SqlCommand("LocalizarVendido", con);
                    pedido.Parameters.AddWithValue("@Id", SqlDbType.Int).Value = Convert.ToInt32(txtidvenda.Text.Trim());
                    pedido.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter ped = new SqlDataAdapter(pedido);
                    DataTable dtped = new DataTable();
                    ped.Fill(dtped);
                    int linhasped = dtped.Rows.Count;
                    if (dtped.Rows.Count > 0)
                    {
                        CarregaCbxProduto();
                        cbxcliente.Enabled = true;
                        cbxcliente.Text = "";
                        cbxcliente.Text = dtped.Rows[0]["nomecliente"].ToString();
                        txttotal.Text = dtped.Rows[0]["total"].ToString();
                        cbxproduto.Enabled = true;
                        txtidproduto.Enabled = true;
                        txtquantidade.Enabled = true;
                        txtvalor.Enabled = true;
                        txttotal.Enabled = true;
                        btnatualizarpedido.Enabled = true;
                        btnfinalizarpedido.Enabled = true;
                        btnfinalizarvenda.Enabled = true;
                        btnnovoitem.Enabled = true;
                        btneditaritem.Enabled = true;
                        btnexcluiritem.Enabled = true;
                        dgvpedido.Columns.Add("ID", "ID");
                        dgvpedido.Columns.Add("Produto", "Produto");
                        dgvpedido.Columns.Add("Quantidade", "Quantidade");
                        dgvpedido.Columns.Add("Valor", "Valor");
                        dgvpedido.Columns.Add("Total", "Total");
                        for (int i = 0; i < linhasped; i++)
                        {
                            DataGridViewRow itemped = new DataGridViewRow();
                            itemped.CreateCells(dgvpedido);
                            itemped.Cells[0].Value = dtped.Rows[i]["id_produto"].ToString();
                            itemped.Cells[1].Value = dtped.Rows[i]["nomeproduto"].ToString();
                            itemped.Cells[2].Value = dtped.Rows[i]["quantidade"].ToString();
                            itemped.Cells[3].Value = dtped.Rows[i]["preco"].ToString();
                            itemped.Cells[4].Value = dtped.Rows[i]["subtotal"].ToString();
                            dgvpedido.Rows.Add(itemped);
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Nenhuma venda localizado. Por favor, verifique se o ID está correto.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            con.Close();
        }
        private void btnatualizarpedido_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Venda SET total = @total WHERE Id=@Id", con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@Id", SqlDbType.Int).Value = Convert.ToInt32(txtidvenda.Text.Trim());
            cmd.Parameters.AddWithValue("@total", SqlDbType.Decimal).Value = Convert.ToDecimal(txttotal.Text);
            cmd.ExecuteNonQuery();
            SqlCommand deletarpedido = new SqlCommand("DELETE FROM Itens_Venda WHERE id_venda = @Id", con);
            deletarpedido.CommandType = CommandType.Text;
            deletarpedido.Parameters.AddWithValue("@Id", SqlDbType.Int).Value = Convert.ToInt32(txtidvenda.Text.Trim());
            deletarpedido.ExecuteNonQuery();
            foreach (DataGridViewRow dr in dgvpedido.Rows)
            {
                SqlCommand itens = new SqlCommand("InserirItensVendidos", con);
                itens.CommandType = CommandType.StoredProcedure;
                itens.Parameters.AddWithValue("@id_venda", SqlDbType.Int).Value = Convert.ToInt32(txtidvenda.Text.Trim());
                itens.Parameters.AddWithValue("@id_produto", SqlDbType.Int).Value = Convert.ToInt32(dr.Cells[0].Value);
                itens.Parameters.AddWithValue("@quantidade", SqlDbType.Int).Value = Convert.ToInt32(dr.Cells[2].Value);
                itens.Parameters.AddWithValue("@preco", SqlDbType.Decimal).Value = Convert.ToDecimal(dr.Cells[3].Value);
                itens.Parameters.AddWithValue("@subtotal", SqlDbType.Decimal).Value = Convert.ToDecimal(dr.Cells[4].Value);
                itens.ExecuteNonQuery();
            }
            con.Close();
            MessageBox.Show("Pedido atualizado com sucesso!", "Atualização do Pedido", MessageBoxButtons.OK, MessageBoxIcon.Information);
            dgvpedido.Rows.Clear();
            dgvpedido.Refresh();
            txtidvenda.Text = string.Empty;
            txttotal.Text = string.Empty;
            txtvalor.Text = string.Empty;
            txtquantidade.Text = string.Empty;
            txtidproduto.Text = string.Empty;
            cbxproduto.Text = string.Empty;
            cbxcliente.Text = string.Empty;
            cbxcliente.Enabled = false;
            cbxproduto.Enabled = false;
            txtidproduto.Enabled = false;
            txtquantidade.Enabled = false;
            txtvalor.Enabled = false;
            txttotal.Enabled = false;
            btnatualizarpedido.Enabled = false;
            btnfinalizarpedido.Enabled = false;
            btnnovoitem.Enabled = false;
            btneditaritem.Enabled = false;
            btnexcluiritem.Enabled = false;
        }
        private void btnfinalizarvenda_Click(object sender, EventArgs e)
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
            }
            con.Open();
            SqlCommand cmd = new SqlCommand("UPDATE Venda SET situacao = @situacao WHERE Id = @Id", con);
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@Id", SqlDbType.Int).Value = Convert.ToInt32(txtidvenda.Text.Trim());
            cmd.Parameters.AddWithValue("@situacao", SqlDbType.NChar).Value = "Fechada";
            cmd.ExecuteNonQuery();
            SqlCommand deletarpedido = new SqlCommand("DELETE FROM Itens_Venda WHERE id_venda = @Id", con);
            deletarpedido.CommandType = CommandType.Text;
            deletarpedido.Parameters.AddWithValue("@Id", SqlDbType.Int).Value = Convert.ToInt32(txtidvenda.Text.Trim());
            deletarpedido.ExecuteNonQuery();
            foreach (DataGridViewRow dr in dgvpedido.Rows)
            {
                SqlCommand itens = new SqlCommand("InserirItensVendidos", con);
                itens.CommandType = CommandType.StoredProcedure;
                itens.Parameters.AddWithValue("@id_venda", SqlDbType.Int).Value = Convert.ToInt32(txtidvenda.Text.Trim());
                itens.Parameters.AddWithValue("@id_produto", SqlDbType.Int).Value = Convert.ToInt32(dr.Cells[0].Value);
                itens.Parameters.AddWithValue("@quantidade", SqlDbType.Int).Value = Convert.ToInt32(dr.Cells[2].Value);
                itens.Parameters.AddWithValue("@preco", SqlDbType.Decimal).Value = Convert.ToDecimal(dr.Cells[3].Value);
                itens.Parameters.AddWithValue("@subtotal", SqlDbType.Decimal).Value = Convert.ToDecimal(dr.Cells[4].Value);
                itens.ExecuteNonQuery();
            }
            con.Close();
            MessageBox.Show("Venda realizada com sucesso!", "Venda", MessageBoxButtons.OK, MessageBoxIcon.Information);
            dgvpedido.Rows.Clear();
            dgvpedido.Refresh();
            txtidvenda.Text = string.Empty;
            txttotal.Text = string.Empty;
            txtvalor.Text = string.Empty;
            txtquantidade.Text = string.Empty;
            txtidproduto.Text = string.Empty;
            cbxproduto.Text = string.Empty;
            cbxcliente.Text = string.Empty;
            txtestoque.Text = string.Empty;
            cbxcliente.Enabled = false;
            cbxproduto.Enabled = false;
            txtidproduto.Enabled = false;
            txtquantidade.Enabled = false;
            txtvalor.Enabled = false;
            txttotal.Enabled = false;
            btnatualizarpedido.Enabled = false;
            btnfinalizarpedido.Enabled = false;
            btnnovoitem.Enabled = false;
            btneditaritem.Enabled = false;
            btnexcluiritem.Enabled = false;
        }















        private void btneditar_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btnexcluiritem_Leave(object sender, EventArgs e)
        {

        }
        private void dgvpedido_Click(object sender, EventArgs e)
        {

        }
    }
}
