﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Oboteco.models;

namespace Oboteco.models
{
    internal class AppDbContext : DbContext
    {

    }
}
