﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oboteco.models
{
    [Table("itens_vendas")]
    internal class itens_vendas
    {
        [Key]
        public int id { get; set; }
        public int id_venda { get; set; }
        public int id_produto { get; set; }
        public int quatidade { get; set; }
        public float preco { get; set; }
        public float subtotal { get; set; }
    }
}
