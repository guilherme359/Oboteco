﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oboteco.models
{
    [Table("produto")]
    internal class produto
    {
        [Key]
        public int id { get; set; }
        public string nome { get; set; }
        public string tipo { get; set; }
        public int quatidade { get; set; }
        public float preco { get; set; }


    }
}
