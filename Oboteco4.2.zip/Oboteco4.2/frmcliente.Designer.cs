﻿namespace Oboteco
{
    partial class frmcliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btncadastrar = new Button();
            label1 = new Label();
            txtid = new TextBox();
            mskcelular = new MaskedTextBox();
            txtnome = new TextBox();
            label2 = new Label();
            txtemail = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            btneditar = new Button();
            btnpesquisar = new Button();
            dgvtabela = new DataGridView();
            mskdata = new MaskedTextBox();
            btnvoltar = new Button();
            btnexcluir = new Button();
            btnlistar = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvtabela).BeginInit();
            SuspendLayout();
            // 
            // btncadastrar
            // 
            btncadastrar.BackColor = Color.Chartreuse;
            btncadastrar.FlatStyle = FlatStyle.Flat;
            btncadastrar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btncadastrar.ForeColor = SystemColors.ActiveCaptionText;
            btncadastrar.Location = new Point(14, 188);
            btncadastrar.Name = "btncadastrar";
            btncadastrar.Size = new Size(97, 50);
            btncadastrar.TabIndex = 0;
            btncadastrar.Text = "CADASTRAR";
            btncadastrar.UseVisualStyleBackColor = false;
            btncadastrar.Click += button1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(14, 11);
            label1.Name = "label1";
            label1.Size = new Size(25, 20);
            label1.TabIndex = 1;
            label1.Text = "ID";
            // 
            // txtid
            // 
            txtid.Location = new Point(14, 37);
            txtid.Name = "txtid";
            txtid.Size = new Size(62, 25);
            txtid.TabIndex = 2;
            // 
            // mskcelular
            // 
            mskcelular.Location = new Point(14, 109);
            mskcelular.Mask = "(99) 00000-0000";
            mskcelular.Name = "mskcelular";
            mskcelular.Size = new Size(97, 25);
            mskcelular.TabIndex = 3;
            // 
            // txtnome
            // 
            txtnome.Location = new Point(95, 37);
            txtnome.Name = "txtnome";
            txtnome.Size = new Size(351, 25);
            txtnome.TabIndex = 5;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(95, 11);
            label2.Name = "label2";
            label2.Size = new Size(54, 20);
            label2.TabIndex = 4;
            label2.Text = "NOME";
            // 
            // txtemail
            // 
            txtemail.Location = new Point(130, 109);
            txtemail.Name = "txtemail";
            txtemail.Size = new Size(283, 25);
            txtemail.TabIndex = 9;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(130, 83);
            label3.Name = "label3";
            label3.Size = new Size(55, 20);
            label3.TabIndex = 8;
            label3.Text = "EMAIL";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(14, 83);
            label4.Name = "label4";
            label4.Size = new Size(74, 20);
            label4.TabIndex = 6;
            label4.Text = "CELULAR";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(494, 11);
            label5.Name = "label5";
            label5.Size = new Size(32, 20);
            label5.TabIndex = 10;
            label5.Text = "DN";
            // 
            // btneditar
            // 
            btneditar.BackColor = Color.DarkOrange;
            btneditar.FlatStyle = FlatStyle.Flat;
            btneditar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btneditar.Location = new Point(117, 188);
            btneditar.Name = "btneditar";
            btneditar.Size = new Size(64, 50);
            btneditar.TabIndex = 12;
            btneditar.Text = "EDITAR";
            btneditar.UseVisualStyleBackColor = false;
            btneditar.Click += btneditar_Click;
            // 
            // btnpesquisar
            // 
            btnpesquisar.BackColor = Color.OrangeRed;
            btnpesquisar.FlatStyle = FlatStyle.Flat;
            btnpesquisar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnpesquisar.Location = new Point(187, 188);
            btnpesquisar.Name = "btnpesquisar";
            btnpesquisar.Size = new Size(88, 50);
            btnpesquisar.TabIndex = 13;
            btnpesquisar.Text = "PESQUISAR";
            btnpesquisar.UseVisualStyleBackColor = false;
            btnpesquisar.Click += btnpesquisar_Click;
            // 
            // dgvtabela
            // 
            dgvtabela.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvtabela.Location = new Point(12, 244);
            dgvtabela.Name = "dgvtabela";
            dgvtabela.RowTemplate.Height = 25;
            dgvtabela.Size = new Size(656, 273);
            dgvtabela.TabIndex = 17;
            dgvtabela.CellContentClick += dataGridView1_CellContentClick;
            // 
            // mskdata
            // 
            mskdata.Location = new Point(494, 37);
            mskdata.Mask = "00/00/0000";
            mskdata.Name = "mskdata";
            mskdata.Size = new Size(84, 25);
            mskdata.TabIndex = 18;
            mskdata.ValidatingType = typeof(DateTime);
            // 
            // btnvoltar
            // 
            btnvoltar.FlatStyle = FlatStyle.Flat;
            btnvoltar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnvoltar.Location = new Point(599, 188);
            btnvoltar.Name = "btnvoltar";
            btnvoltar.Size = new Size(69, 50);
            btnvoltar.TabIndex = 19;
            btnvoltar.Text = "VOLTAR";
            btnvoltar.UseVisualStyleBackColor = true;
            btnvoltar.Click += btnvoltar_Click;
            // 
            // btnexcluir
            // 
            btnexcluir.BackColor = Color.Firebrick;
            btnexcluir.FlatStyle = FlatStyle.Flat;
            btnexcluir.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnexcluir.Location = new Point(513, 188);
            btnexcluir.Name = "btnexcluir";
            btnexcluir.Size = new Size(80, 50);
            btnexcluir.TabIndex = 20;
            btnexcluir.Text = "EXCLUIR";
            btnexcluir.UseVisualStyleBackColor = false;
            btnexcluir.Click += btnexcluir_Click;
            // 
            // btnlistar
            // 
            btnlistar.BackColor = Color.Yellow;
            btnlistar.FlatStyle = FlatStyle.Flat;
            btnlistar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnlistar.Location = new Point(281, 188);
            btnlistar.Name = "btnlistar";
            btnlistar.Size = new Size(80, 50);
            btnlistar.TabIndex = 21;
            btnlistar.Text = "LISTAR";
            btnlistar.UseVisualStyleBackColor = false;
            btnlistar.Click += btnlistar_Click;
            // 
            // frmcliente
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Gainsboro;
            ClientSize = new Size(684, 529);
            Controls.Add(btnlistar);
            Controls.Add(btnexcluir);
            Controls.Add(btnvoltar);
            Controls.Add(mskdata);
            Controls.Add(dgvtabela);
            Controls.Add(btnpesquisar);
            Controls.Add(btneditar);
            Controls.Add(label5);
            Controls.Add(txtemail);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(txtnome);
            Controls.Add(label2);
            Controls.Add(mskcelular);
            Controls.Add(txtid);
            Controls.Add(label1);
            Controls.Add(btncadastrar);
            Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            Name = "frmcliente";
            Text = "frmcliente";
            Load += frmcliente_Load;
            ((System.ComponentModel.ISupportInitialize)dgvtabela).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btncadastrar;
        private Label label1;
        private TextBox txtid;
        private MaskedTextBox mskcelular;
        private TextBox txtnome;
        private Label label2;
        private TextBox txtemail;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button btneditar;
        private Button button3;
        private Button btnpesquisar;
        private Button button5;
        private Button button6;
        private DataGridView dgvtabela;
        private MaskedTextBox mskdata;
        private Button btnvoltar;
        private Button btnexcluir;
        private Button btnlistar;
    }
}