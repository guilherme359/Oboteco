﻿namespace Oboteco
{
    partial class frmprincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            menuStrip1 = new MenuStrip();
            cADASTROSToolStripMenuItem = new ToolStripMenuItem();
            cLIENTESToolStripMenuItem = new ToolStripMenuItem();
            fUNCIONARIOSToolStripMenuItem = new ToolStripMenuItem();
            pRODUTOSToolStripMenuItem = new ToolStripMenuItem();
            vENDASToolStripMenuItem = new ToolStripMenuItem();
            sAIRToolStripMenuItem = new ToolStripMenuItem();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            pictureBox5 = new PictureBox();
            lsvAbertas = new ListView();
            lblTotalDia = new Label();
            timer1 = new System.Windows.Forms.Timer(components);
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.BackColor = SystemColors.ButtonShadow;
            menuStrip1.Items.AddRange(new ToolStripItem[] { cADASTROSToolStripMenuItem, vENDASToolStripMenuItem, sAIRToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1229, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // cADASTROSToolStripMenuItem
            // 
            cADASTROSToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cLIENTESToolStripMenuItem, fUNCIONARIOSToolStripMenuItem, pRODUTOSToolStripMenuItem });
            cADASTROSToolStripMenuItem.Name = "cADASTROSToolStripMenuItem";
            cADASTROSToolStripMenuItem.Size = new Size(85, 20);
            cADASTROSToolStripMenuItem.Text = "CADASTROS";
            cADASTROSToolStripMenuItem.Click += cADASTROSToolStripMenuItem_Click;
            // 
            // cLIENTESToolStripMenuItem
            // 
            cLIENTESToolStripMenuItem.Name = "cLIENTESToolStripMenuItem";
            cLIENTESToolStripMenuItem.Size = new Size(162, 22);
            cLIENTESToolStripMenuItem.Text = "CLIENTES";
            cLIENTESToolStripMenuItem.Click += cLIENTESToolStripMenuItem_Click;
            // 
            // fUNCIONARIOSToolStripMenuItem
            // 
            fUNCIONARIOSToolStripMenuItem.Name = "fUNCIONARIOSToolStripMenuItem";
            fUNCIONARIOSToolStripMenuItem.Size = new Size(162, 22);
            fUNCIONARIOSToolStripMenuItem.Text = "FUNCIONARIOS ";
            fUNCIONARIOSToolStripMenuItem.Click += fUNCIONARIOSToolStripMenuItem_Click;
            // 
            // pRODUTOSToolStripMenuItem
            // 
            pRODUTOSToolStripMenuItem.Name = "pRODUTOSToolStripMenuItem";
            pRODUTOSToolStripMenuItem.Size = new Size(162, 22);
            pRODUTOSToolStripMenuItem.Text = "PRODUTOS";
            pRODUTOSToolStripMenuItem.Click += pRODUTOSToolStripMenuItem_Click;
            // 
            // vENDASToolStripMenuItem
            // 
            vENDASToolStripMenuItem.Name = "vENDASToolStripMenuItem";
            vENDASToolStripMenuItem.Size = new Size(63, 20);
            vENDASToolStripMenuItem.Text = "VENDAS";
            vENDASToolStripMenuItem.Click += vENDASToolStripMenuItem_Click;
            // 
            // sAIRToolStripMenuItem
            // 
            sAIRToolStripMenuItem.Name = "sAIRToolStripMenuItem";
            sAIRToolStripMenuItem.Size = new Size(43, 20);
            sAIRToolStripMenuItem.Text = "SAIR";
            sAIRToolStripMenuItem.Click += sAIRToolStripMenuItem_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = Properties.Resources.human;
            pictureBox1.Location = new Point(12, 27);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(177, 189);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(12, 219);
            label1.Name = "label1";
            label1.Size = new Size(82, 21);
            label1.TabIndex = 2;
            label1.Text = "CLIENTES";
            // 
            // pictureBox2
            // 
            pictureBox2.Cursor = Cursors.Hand;
            pictureBox2.Image = Properties.Resources.waiter;
            pictureBox2.Location = new Point(260, 27);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(177, 189);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Cursor = Cursors.Hand;
            pictureBox3.Image = Properties.Resources.healthy_food;
            pictureBox3.Location = new Point(513, 27);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(177, 189);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 4;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Cursor = Cursors.Hand;
            pictureBox4.Image = Properties.Resources.coins;
            pictureBox4.Location = new Point(759, 27);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(177, 189);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 5;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(260, 219);
            label2.Name = "label2";
            label2.Size = new Size(130, 21);
            label2.TabIndex = 6;
            label2.Text = "FUNCIONARIOS";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(513, 219);
            label3.Name = "label3";
            label3.Size = new Size(95, 21);
            label3.TabIndex = 7;
            label3.Text = "PRODUTOS";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(759, 219);
            label4.Name = "label4";
            label4.Size = new Size(75, 21);
            label4.TabIndex = 8;
            label4.Text = "VENDAS";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(1004, 219);
            label5.Name = "label5";
            label5.Size = new Size(45, 21);
            label5.TabIndex = 11;
            label5.Text = "SAIR";
            // 
            // pictureBox5
            // 
            pictureBox5.Cursor = Cursors.Hand;
            pictureBox5.Image = Properties.Resources.exit;
            pictureBox5.Location = new Point(1004, 27);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(177, 189);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 10;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // lsvAbertas
            // 
            lsvAbertas.Location = new Point(558, 288);
            lsvAbertas.Name = "lsvAbertas";
            lsvAbertas.Size = new Size(565, 304);
            lsvAbertas.TabIndex = 12;
            lsvAbertas.UseCompatibleStateImageBehavior = false;
            lsvAbertas.ItemActivate += lsvAbertas_ItemActivate;
            // 
            // lblTotalDia
            // 
            lblTotalDia.AutoSize = true;
            lblTotalDia.Font = new Font("Segoe UI", 72F, FontStyle.Bold, GraphicsUnit.Point);
            lblTotalDia.Location = new Point(54, 347);
            lblTotalDia.Name = "lblTotalDia";
            lblTotalDia.Size = new Size(0, 128);
            lblTotalDia.TabIndex = 13;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // frmprincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(1229, 641);
            Controls.Add(lblTotalDia);
            Controls.Add(lsvAbertas);
            Controls.Add(label5);
            Controls.Add(pictureBox5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            MaximizeBox = false;
            MinimizeBox = false;
            Name = "frmprincipal";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "O Boteco";
            WindowState = FormWindowState.Maximized;
            Load += frmprincipal_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem cADASTROSToolStripMenuItem;
        private ToolStripMenuItem cLIENTESToolStripMenuItem;
        private ToolStripMenuItem fUNCIONARIOSToolStripMenuItem;
        private ToolStripMenuItem pRODUTOSToolStripMenuItem;
        private ToolStripMenuItem vENDASToolStripMenuItem;
        private ToolStripMenuItem sAIRToolStripMenuItem;
        private PictureBox pictureBox1;
        private Label label1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private PictureBox pictureBox5;
        private ListView lsvAbertas;
        private Label lblTotalDia;
        private System.Windows.Forms.Timer timer1;
    }
}