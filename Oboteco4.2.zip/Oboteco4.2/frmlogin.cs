using System.Security.Cryptography.Pkcs;

namespace Oboteco
{
    public partial class frmlogin : Form
    {
        public frmlogin()
        {
            InitializeComponent();
            frmsplash splash = new frmsplash();
            splash.Show();
            Application.DoEvents();
            Thread.Sleep(3000);
            splash.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string login = txtlogin.Text.Trim();
            string senha = txtsenha.Text.Trim();
            if (login == "admin" && senha == "admin")
            {
                frmprincipal principal = new frmprincipal();
                principal.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("login ou senha incorretas. tente novamente", "erro!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtlogin.Clear();
                txtsenha.Clear();
                txtlogin.Focus();
            }

        }

        private void frmlogin_Load(object sender, EventArgs e)
        {
            this.ActiveControl = txtlogin;
        }
    }
}