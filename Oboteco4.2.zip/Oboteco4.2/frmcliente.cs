﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Oboteco.controllers;
using Oboteco.models;

namespace Oboteco
{
    public partial class frmcliente : Form
    {
        Controlecliente controle = new Controlecliente();
        public frmcliente()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string id = txtid.Text.Trim();
            string nome = txtnome.Text.Trim();
            string celular = mskcelular.Text.Trim();
            string email = txtemail.Text.Trim();
            string data = mskdata.Text.Trim();

            if (nome == string.Empty || celular == string.Empty || email == string.Empty || data == string.Empty)
            {
                MessageBox.Show("preencha este campo‼");
                return;
            }

            if (controle.inserirClientes(nome, celular, email, data))
            {
                MessageBox.Show("!!!!!!!!--USUARIO CADASTRADO--!!!!!!!!");

                txtnome.Text = string.Empty;
                mskcelular.Text = string.Empty;
                txtemail.Text = string.Empty;
                mskdata.Text = string.Empty;

            }
        }

        private void btnvoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmcliente_Load(object sender, EventArgs e)
        {

        }

        private void btneditar_Click(object sender, EventArgs e)
        {
            string id = txtid.Text.Trim();
            string nome = txtnome.Text.Trim();
            string celular = mskcelular.Text.Trim();
            string email = txtemail.Text.Trim();
            string data = mskdata.Text.Trim();

            if (nome == string.Empty || celular == string.Empty || email == string.Empty || data == string.Empty)
            {
                MessageBox.Show("preencha este campo‼");
                return;
            }

            if (controle.EditarCliente(id, nome, celular, email, data))
            {
                MessageBox.Show("!!!!!!!!--USUARIO EDITADO--!!!!!!!!");

                txtnome.Text = string.Empty;
                mskcelular.Text = string.Empty;
                txtemail.Text = string.Empty;
                mskdata.Text = string.Empty;

            }
        }

        private void btnexcluir_Click(object sender, EventArgs e)
        {
            controle.ExcluirCliente(txtid.Text.Trim());
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnlistar_Click(object sender, EventArgs e)
        {
            clientes cliente = new clientes();
            List<clientes> cli = new List<clientes>();
            cli = controle.Listar(cli);
            dgvtabela.DataSource = cli;
        }

        private void btnpesquisar_Click(object sender, EventArgs e)
        {
            List<string> dr = controle.LocalizarCliente(txtid.Text.Trim());
            if (dr != null)
            {
                this.txtid.Text = dr[0];
                this.txtnome.Text = dr[1];
                this.txtemail.Text = dr[2];
                this.mskcelular.Text = dr[3];
                this.mskdata.Text = dr[4];
            }
            
        }
    }
}
