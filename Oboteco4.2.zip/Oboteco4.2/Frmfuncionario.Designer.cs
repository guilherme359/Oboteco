﻿namespace Oboteco
{
    partial class Frmfuncionario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnexcluir = new Button();
            btnvoltar = new Button();
            dgvtabela = new DataGridView();
            btnpesquisar = new Button();
            btneditar = new Button();
            label5 = new Label();
            txtemail = new TextBox();
            label3 = new Label();
            label4 = new Label();
            txtnome = new TextBox();
            label2 = new Label();
            txtid = new TextBox();
            label1 = new Label();
            btncadastrar = new Button();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvtabela).BeginInit();
            SuspendLayout();
            // 
            // btnexcluir
            // 
            btnexcluir.BackColor = Color.Firebrick;
            btnexcluir.FlatStyle = FlatStyle.Flat;
            btnexcluir.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnexcluir.Location = new Point(280, 281);
            btnexcluir.Name = "btnexcluir";
            btnexcluir.Size = new Size(80, 50);
            btnexcluir.TabIndex = 36;
            btnexcluir.Text = "EXCLUIR";
            btnexcluir.UseVisualStyleBackColor = false;
            // 
            // btnvoltar
            // 
            btnvoltar.FlatStyle = FlatStyle.Flat;
            btnvoltar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnvoltar.Location = new Point(599, 187);
            btnvoltar.Name = "btnvoltar";
            btnvoltar.Size = new Size(69, 50);
            btnvoltar.TabIndex = 35;
            btnvoltar.Text = "VOLTAR";
            btnvoltar.UseVisualStyleBackColor = true;
            // 
            // dgvtabela
            // 
            dgvtabela.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvtabela.Location = new Point(12, 337);
            dgvtabela.Name = "dgvtabela";
            dgvtabela.RowTemplate.Height = 25;
            dgvtabela.Size = new Size(656, 179);
            dgvtabela.TabIndex = 33;
            // 
            // btnpesquisar
            // 
            btnpesquisar.BackColor = Color.OrangeRed;
            btnpesquisar.FlatStyle = FlatStyle.Flat;
            btnpesquisar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnpesquisar.Location = new Point(186, 281);
            btnpesquisar.Name = "btnpesquisar";
            btnpesquisar.Size = new Size(88, 50);
            btnpesquisar.TabIndex = 32;
            btnpesquisar.Text = "PESQUISAR";
            btnpesquisar.UseVisualStyleBackColor = false;
            // 
            // btneditar
            // 
            btneditar.BackColor = Color.DarkOrange;
            btneditar.FlatStyle = FlatStyle.Flat;
            btneditar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btneditar.Location = new Point(116, 281);
            btneditar.Name = "btneditar";
            btneditar.Size = new Size(64, 50);
            btneditar.TabIndex = 31;
            btneditar.Text = "EDITAR";
            btneditar.UseVisualStyleBackColor = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(14, 65);
            label5.Name = "label5";
            label5.Size = new Size(35, 20);
            label5.TabIndex = 30;
            label5.Text = "CPF";
            // 
            // txtemail
            // 
            txtemail.Location = new Point(14, 198);
            txtemail.Name = "txtemail";
            txtemail.Size = new Size(195, 23);
            txtemail.TabIndex = 29;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(14, 175);
            label3.Name = "label3";
            label3.Size = new Size(59, 20);
            label3.TabIndex = 28;
            label3.Text = "SENHA";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(14, 126);
            label4.Name = "label4";
            label4.Size = new Size(56, 20);
            label4.TabIndex = 27;
            label4.Text = "LOGIN";
            // 
            // txtnome
            // 
            txtnome.Location = new Point(76, 36);
            txtnome.Name = "txtnome";
            txtnome.Size = new Size(351, 23);
            txtnome.TabIndex = 26;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(76, 13);
            label2.Name = "label2";
            label2.Size = new Size(54, 20);
            label2.TabIndex = 25;
            label2.Text = "NOME";
            // 
            // txtid
            // 
            txtid.Location = new Point(14, 36);
            txtid.Name = "txtid";
            txtid.Size = new Size(56, 23);
            txtid.TabIndex = 23;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(14, 13);
            label1.Name = "label1";
            label1.Size = new Size(25, 20);
            label1.TabIndex = 22;
            label1.Text = "ID";
            // 
            // btncadastrar
            // 
            btncadastrar.BackColor = Color.Chartreuse;
            btncadastrar.FlatStyle = FlatStyle.Flat;
            btncadastrar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btncadastrar.ForeColor = SystemColors.ActiveCaptionText;
            btncadastrar.Location = new Point(13, 281);
            btncadastrar.Name = "btncadastrar";
            btncadastrar.Size = new Size(97, 50);
            btncadastrar.TabIndex = 21;
            btncadastrar.Text = "CADASTRAR";
            btncadastrar.UseVisualStyleBackColor = false;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(14, 149);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(195, 23);
            textBox1.TabIndex = 37;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(14, 91);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(177, 23);
            textBox2.TabIndex = 38;
            // 
            // Frmfuncionario
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(684, 526);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(btnexcluir);
            Controls.Add(btnvoltar);
            Controls.Add(dgvtabela);
            Controls.Add(btnpesquisar);
            Controls.Add(btneditar);
            Controls.Add(label5);
            Controls.Add(txtemail);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(txtnome);
            Controls.Add(label2);
            Controls.Add(txtid);
            Controls.Add(label1);
            Controls.Add(btncadastrar);
            Name = "Frmfuncionario";
            Text = "Frmfuncionario";
            ((System.ComponentModel.ISupportInitialize)dgvtabela).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnexcluir;
        private Button btnvoltar;
        private DataGridView dgvtabela;
        private Button btnpesquisar;
        private Button btneditar;
        private Label label5;
        private TextBox txtemail;
        private Label label3;
        private Label label4;
        private TextBox txtnome;
        private Label label2;
        private TextBox txtid;
        private Label label1;
        private Button btncadastrar;
        private TextBox textBox1;
        private TextBox textBox2;
    }
}