﻿namespace Oboteco
{
    partial class Frmproduto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnexcluir = new Button();
            btnvoltar = new Button();
            dgvtabela = new DataGridView();
            btnpesquisar = new Button();
            btneditar = new Button();
            txtemail = new TextBox();
            label3 = new Label();
            txtnome = new TextBox();
            label2 = new Label();
            txtid = new TextBox();
            label1 = new Label();
            btncadastrar = new Button();
            label4 = new Label();
            textBox1 = new TextBox();
            label5 = new Label();
            textBox2 = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvtabela).BeginInit();
            SuspendLayout();
            // 
            // btnexcluir
            // 
            btnexcluir.BackColor = Color.Firebrick;
            btnexcluir.FlatStyle = FlatStyle.Flat;
            btnexcluir.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnexcluir.Location = new Point(120, 187);
            btnexcluir.Name = "btnexcluir";
            btnexcluir.Size = new Size(80, 50);
            btnexcluir.TabIndex = 36;
            btnexcluir.Text = "EXCLUIR";
            btnexcluir.UseVisualStyleBackColor = false;
            // 
            // btnvoltar
            // 
            btnvoltar.FlatStyle = FlatStyle.Flat;
            btnvoltar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnvoltar.Location = new Point(599, 187);
            btnvoltar.Name = "btnvoltar";
            btnvoltar.Size = new Size(69, 50);
            btnvoltar.TabIndex = 35;
            btnvoltar.Text = "VOLTAR";
            btnvoltar.UseVisualStyleBackColor = true;
            // 
            // dgvtabela
            // 
            dgvtabela.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvtabela.Location = new Point(12, 243);
            dgvtabela.Name = "dgvtabela";
            dgvtabela.RowTemplate.Height = 25;
            dgvtabela.Size = new Size(656, 273);
            dgvtabela.TabIndex = 33;
            // 
            // btnpesquisar
            // 
            btnpesquisar.BackColor = Color.OrangeRed;
            btnpesquisar.FlatStyle = FlatStyle.Flat;
            btnpesquisar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btnpesquisar.Location = new Point(14, 187);
            btnpesquisar.Name = "btnpesquisar";
            btnpesquisar.Size = new Size(88, 50);
            btnpesquisar.TabIndex = 32;
            btnpesquisar.Text = "PESQUISAR";
            btnpesquisar.UseVisualStyleBackColor = false;
            // 
            // btneditar
            // 
            btneditar.BackColor = Color.DarkOrange;
            btneditar.FlatStyle = FlatStyle.Flat;
            btneditar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btneditar.Location = new Point(579, 76);
            btneditar.Name = "btneditar";
            btneditar.Size = new Size(97, 50);
            btneditar.TabIndex = 31;
            btneditar.Text = "EDITAR";
            btneditar.UseVisualStyleBackColor = false;
            // 
            // txtemail
            // 
            txtemail.Location = new Point(14, 98);
            txtemail.Name = "txtemail";
            txtemail.Size = new Size(135, 23);
            txtemail.TabIndex = 29;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(14, 72);
            label3.Name = "label3";
            label3.Size = new Size(109, 20);
            label3.TabIndex = 28;
            label3.Text = "QUANTIDADE";
            // 
            // txtnome
            // 
            txtnome.Location = new Point(95, 36);
            txtnome.Name = "txtnome";
            txtnome.Size = new Size(393, 23);
            txtnome.TabIndex = 26;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(95, 10);
            label2.Name = "label2";
            label2.Size = new Size(54, 20);
            label2.TabIndex = 25;
            label2.Text = "NOME";
            // 
            // txtid
            // 
            txtid.Location = new Point(14, 36);
            txtid.Name = "txtid";
            txtid.Size = new Size(62, 23);
            txtid.TabIndex = 23;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(14, 10);
            label1.Name = "label1";
            label1.Size = new Size(25, 20);
            label1.TabIndex = 22;
            label1.Text = "ID";
            // 
            // btncadastrar
            // 
            btncadastrar.BackColor = Color.Chartreuse;
            btncadastrar.FlatStyle = FlatStyle.Flat;
            btncadastrar.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            btncadastrar.ForeColor = SystemColors.ActiveCaptionText;
            btncadastrar.Location = new Point(579, 20);
            btncadastrar.Name = "btncadastrar";
            btncadastrar.Size = new Size(97, 50);
            btncadastrar.TabIndex = 21;
            btncadastrar.Text = "CADASTRAR";
            btncadastrar.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(165, 72);
            label4.Name = "label4";
            label4.Size = new Size(56, 20);
            label4.TabIndex = 39;
            label4.Text = "PREÇO";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(334, 98);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(154, 23);
            textBox1.TabIndex = 38;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(334, 72);
            label5.Name = "label5";
            label5.Size = new Size(43, 20);
            label5.TabIndex = 37;
            label5.Text = "TIPO";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(165, 98);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(154, 23);
            textBox2.TabIndex = 40;
            // 
            // Frmproduto
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(688, 541);
            Controls.Add(textBox2);
            Controls.Add(label4);
            Controls.Add(textBox1);
            Controls.Add(label5);
            Controls.Add(btnexcluir);
            Controls.Add(btnvoltar);
            Controls.Add(dgvtabela);
            Controls.Add(btnpesquisar);
            Controls.Add(btneditar);
            Controls.Add(txtemail);
            Controls.Add(label3);
            Controls.Add(txtnome);
            Controls.Add(label2);
            Controls.Add(txtid);
            Controls.Add(label1);
            Controls.Add(btncadastrar);
            Name = "Frmproduto";
            Text = "Frmproduto";
            ((System.ComponentModel.ISupportInitialize)dgvtabela).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnexcluir;
        private Button btnvoltar;
        private DataGridView dgvtabela;
        private Button btnpesquisar;
        private Button btneditar;
        private TextBox txtemail;
        private Label label3;
        private TextBox txtnome;
        private Label label2;
        private TextBox txtid;
        private Label label1;
        private Button btncadastrar;
        private Label label4;
        private TextBox textBox1;
        private Label label5;
        private TextBox textBox2;
    }
}