﻿namespace Oboteco
{
    partial class Frmvendas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnvoltar = new Button();
            panel2 = new Panel();
            cbxproduto = new ComboBox();
            cbxcliente = new ComboBox();
            btnatualizarpedido = new Button();
            btnnovopedido = new Button();
            txtestoque = new TextBox();
            txtidproduto = new TextBox();
            label2 = new Label();
            btnexcluiritem = new Button();
            label3 = new Label();
            btneditaritem = new Button();
            txtvalor = new TextBox();
            btnnovoitem = new Button();
            txtidvenda = new TextBox();
            btnlocalizar = new Button();
            label13 = new Label();
            panel4 = new Panel();
            label6 = new Label();
            label7 = new Label();
            txtquantidade = new TextBox();
            label8 = new Label();
            label9 = new Label();
            label12 = new Label();
            txttotal = new TextBox();
            label1 = new Label();
            dgvpedido = new DataGridView();
            btnfinalizarvenda = new Button();
            btnfinalizarpedido = new Button();
            panel2.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvpedido).BeginInit();
            SuspendLayout();
            // 
            // btnvoltar
            // 
            btnvoltar.BackColor = Color.Red;
            btnvoltar.FlatStyle = FlatStyle.Flat;
            btnvoltar.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btnvoltar.Location = new Point(481, 509);
            btnvoltar.Name = "btnvoltar";
            btnvoltar.Size = new Size(61, 36);
            btnvoltar.TabIndex = 51;
            btnvoltar.Text = "VOLTAR";
            btnvoltar.UseVisualStyleBackColor = false;
            btnvoltar.Click += btnvoltar_Click;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.Control;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(cbxproduto);
            panel2.Controls.Add(cbxcliente);
            panel2.Controls.Add(btnatualizarpedido);
            panel2.Controls.Add(btnnovopedido);
            panel2.Controls.Add(txtestoque);
            panel2.Controls.Add(txtidproduto);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(btnexcluiritem);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(btneditaritem);
            panel2.Controls.Add(txtvalor);
            panel2.Controls.Add(btnnovoitem);
            panel2.Controls.Add(txtidvenda);
            panel2.Controls.Add(btnlocalizar);
            panel2.Controls.Add(label13);
            panel2.Controls.Add(panel4);
            panel2.Controls.Add(label7);
            panel2.Controls.Add(txtquantidade);
            panel2.Controls.Add(label8);
            panel2.Controls.Add(label9);
            panel2.Controls.Add(label12);
            panel2.Location = new Point(10, 10);
            panel2.Name = "panel2";
            panel2.Size = new Size(532, 326);
            panel2.TabIndex = 72;
            panel2.Paint += panel2_Paint;
            // 
            // cbxproduto
            // 
            cbxproduto.FormattingEnabled = true;
            cbxproduto.Location = new Point(12, 171);
            cbxproduto.Name = "cbxproduto";
            cbxproduto.Size = new Size(259, 23);
            cbxproduto.TabIndex = 80;
            cbxproduto.SelectedIndexChanged += cbxproduto_SelectedIndexChanged;
            // 
            // cbxcliente
            // 
            cbxcliente.FormattingEnabled = true;
            cbxcliente.Location = new Point(12, 124);
            cbxcliente.Name = "cbxcliente";
            cbxcliente.Size = new Size(259, 23);
            cbxcliente.TabIndex = 79;
            // 
            // btnatualizarpedido
            // 
            btnatualizarpedido.BackColor = Color.Gold;
            btnatualizarpedido.FlatStyle = FlatStyle.Flat;
            btnatualizarpedido.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnatualizarpedido.Location = new Point(441, 93);
            btnatualizarpedido.Name = "btnatualizarpedido";
            btnatualizarpedido.Size = new Size(85, 40);
            btnatualizarpedido.TabIndex = 78;
            btnatualizarpedido.Text = "ATUALIZAR PEDIDO";
            btnatualizarpedido.UseVisualStyleBackColor = false;
            btnatualizarpedido.Click += btnatualizarpedido_Click;
            // 
            // btnnovopedido
            // 
            btnnovopedido.BackColor = Color.SlateBlue;
            btnnovopedido.FlatStyle = FlatStyle.Flat;
            btnnovopedido.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnnovopedido.ForeColor = SystemColors.ActiveCaptionText;
            btnnovopedido.Location = new Point(441, 48);
            btnnovopedido.Name = "btnnovopedido";
            btnnovopedido.Size = new Size(85, 40);
            btnnovopedido.TabIndex = 77;
            btnnovopedido.Text = "NOVO PEDIDO";
            btnnovopedido.UseVisualStyleBackColor = false;
            btnnovopedido.Click += btnnovopedido_Click;
            // 
            // txtestoque
            // 
            txtestoque.Location = new Point(137, 285);
            txtestoque.Name = "txtestoque";
            txtestoque.Size = new Size(117, 23);
            txtestoque.TabIndex = 76;
            // 
            // txtidproduto
            // 
            txtidproduto.Location = new Point(137, 229);
            txtidproduto.Name = "txtidproduto";
            txtidproduto.Size = new Size(117, 23);
            txtidproduto.TabIndex = 75;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(135, 209);
            label2.Name = "label2";
            label2.Size = new Size(89, 17);
            label2.TabIndex = 74;
            label2.Text = "ID PRODUTO";
            // 
            // btnexcluiritem
            // 
            btnexcluiritem.BackColor = Color.Firebrick;
            btnexcluiritem.FlatStyle = FlatStyle.Flat;
            btnexcluiritem.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnexcluiritem.Location = new Point(260, 286);
            btnexcluiritem.Name = "btnexcluiritem";
            btnexcluiritem.Size = new Size(93, 23);
            btnexcluiritem.TabIndex = 73;
            btnexcluiritem.Text = "EXCLUIR ITEM";
            btnexcluiritem.UseVisualStyleBackColor = false;
            btnexcluiritem.Click += btnexcluiritem_Click;
            btnexcluiritem.Leave += btnexcluiritem_Leave;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(137, 265);
            label3.Name = "label3";
            label3.Size = new Size(66, 17);
            label3.TabIndex = 73;
            label3.Text = "ESTOQUE";
            // 
            // btneditaritem
            // 
            btneditaritem.BackColor = Color.DarkOrange;
            btneditaritem.FlatStyle = FlatStyle.Flat;
            btneditaritem.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            btneditaritem.Location = new Point(260, 257);
            btneditaritem.Name = "btneditaritem";
            btneditaritem.Size = new Size(93, 23);
            btneditaritem.TabIndex = 70;
            btneditaritem.Text = "EDITAR ITEM";
            btneditaritem.UseVisualStyleBackColor = false;
            btneditaritem.Click += btneditaritem_Click;
            // 
            // txtvalor
            // 
            txtvalor.Location = new Point(12, 285);
            txtvalor.Name = "txtvalor";
            txtvalor.Size = new Size(117, 23);
            txtvalor.TabIndex = 72;
            // 
            // btnnovoitem
            // 
            btnnovoitem.BackColor = Color.Chartreuse;
            btnnovoitem.FlatStyle = FlatStyle.Flat;
            btnnovoitem.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnnovoitem.ForeColor = SystemColors.ActiveCaptionText;
            btnnovoitem.Location = new Point(260, 228);
            btnnovoitem.Name = "btnnovoitem";
            btnnovoitem.Size = new Size(93, 23);
            btnnovoitem.TabIndex = 69;
            btnnovoitem.Text = "NOVO ITEM";
            btnnovoitem.UseVisualStyleBackColor = false;
            btnnovoitem.Click += btnnovoitem_Click;
            // 
            // txtidvenda
            // 
            txtidvenda.Location = new Point(12, 71);
            txtidvenda.Name = "txtidvenda";
            txtidvenda.Size = new Size(102, 23);
            txtidvenda.TabIndex = 67;
            // 
            // btnlocalizar
            // 
            btnlocalizar.BackColor = Color.Cyan;
            btnlocalizar.FlatStyle = FlatStyle.Flat;
            btnlocalizar.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnlocalizar.Location = new Point(120, 71);
            btnlocalizar.Name = "btnlocalizar";
            btnlocalizar.Size = new Size(85, 23);
            btnlocalizar.TabIndex = 71;
            btnlocalizar.Text = "LOCALIZAR";
            btnlocalizar.UseVisualStyleBackColor = false;
            btnlocalizar.Click += btnlocalizar_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label13.Location = new Point(10, 51);
            label13.Name = "label13";
            label13.Size = new Size(71, 17);
            label13.TabIndex = 66;
            label13.Text = "ID VENDA";
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.ActiveCaption;
            panel4.BorderStyle = BorderStyle.FixedSingle;
            panel4.Controls.Add(label6);
            panel4.Location = new Point(3, 3);
            panel4.Name = "panel4";
            panel4.Size = new Size(524, 41);
            panel4.TabIndex = 65;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(216, 4);
            label6.Name = "label6";
            label6.Size = new Size(97, 30);
            label6.TabIndex = 0;
            label6.Text = "VENDAS";
            label6.Click += label6_Click;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(12, 151);
            label7.Name = "label7";
            label7.Size = new Size(71, 17);
            label7.TabIndex = 62;
            label7.Text = "PRODUTO";
            // 
            // txtquantidade
            // 
            txtquantidade.Location = new Point(12, 229);
            txtquantidade.Name = "txtquantidade";
            txtquantidade.Size = new Size(117, 23);
            txtquantidade.TabIndex = 61;
            txtquantidade.Leave += txtquantidade_Leave;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(10, 209);
            label8.Name = "label8";
            label8.Size = new Size(94, 17);
            label8.TabIndex = 60;
            label8.Text = "QUANTIDADE";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(12, 265);
            label9.Name = "label9";
            label9.Size = new Size(69, 17);
            label9.TabIndex = 59;
            label9.Text = "VALOR R$";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label12.Location = new Point(12, 104);
            label12.Name = "label12";
            label12.Size = new Size(59, 17);
            label12.TabIndex = 55;
            label12.Text = "CLIENTE";
            // 
            // txttotal
            // 
            txttotal.Location = new Point(72, 514);
            txttotal.Name = "txttotal";
            txttotal.Size = new Size(117, 23);
            txttotal.TabIndex = 73;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(10, 515);
            label1.Name = "label1";
            label1.Size = new Size(56, 21);
            label1.TabIndex = 72;
            label1.Text = "TOTAL";
            // 
            // dgvpedido
            // 
            dgvpedido.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvpedido.Location = new Point(10, 350);
            dgvpedido.Name = "dgvpedido";
            dgvpedido.RowTemplate.Height = 25;
            dgvpedido.Size = new Size(441, 162);
            dgvpedido.TabIndex = 74;
            dgvpedido.CellClick += dgvpedido_CellClick;
            dgvpedido.Click += dgvpedido_Click;
            // 
            // btnfinalizarvenda
            // 
            btnfinalizarvenda.BackColor = Color.Crimson;
            btnfinalizarvenda.FlatStyle = FlatStyle.Flat;
            btnfinalizarvenda.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnfinalizarvenda.Location = new Point(457, 396);
            btnfinalizarvenda.Name = "btnfinalizarvenda";
            btnfinalizarvenda.Size = new Size(85, 40);
            btnfinalizarvenda.TabIndex = 78;
            btnfinalizarvenda.Text = "FINALIZAR VENDA";
            btnfinalizarvenda.UseVisualStyleBackColor = false;
            btnfinalizarvenda.Click += btnfinalizarvenda_Click;
            // 
            // btnfinalizarpedido
            // 
            btnfinalizarpedido.BackColor = Color.PaleGreen;
            btnfinalizarpedido.FlatStyle = FlatStyle.Flat;
            btnfinalizarpedido.Font = new Font("Segoe UI", 8.25F, FontStyle.Bold, GraphicsUnit.Point);
            btnfinalizarpedido.ForeColor = SystemColors.ActiveCaptionText;
            btnfinalizarpedido.Location = new Point(457, 350);
            btnfinalizarpedido.Name = "btnfinalizarpedido";
            btnfinalizarpedido.Size = new Size(85, 40);
            btnfinalizarpedido.TabIndex = 77;
            btnfinalizarpedido.Text = "FINALIZAR PEDIDO";
            btnfinalizarpedido.UseVisualStyleBackColor = false;
            btnfinalizarpedido.Click += btnfinalizarpedido_Click;
            // 
            // Frmvendas
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(552, 553);
            Controls.Add(btnfinalizarvenda);
            Controls.Add(dgvpedido);
            Controls.Add(btnfinalizarpedido);
            Controls.Add(txttotal);
            Controls.Add(label1);
            Controls.Add(panel2);
            Controls.Add(btnvoltar);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Frmvendas";
            RightToLeft = RightToLeft.Yes;
            Text = "Frmvendas";
            Load += Frmvendas_Load;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgvpedido).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnvoltar;
        private Panel panel2;
        private TextBox txtidvenda;
        private Label label13;
        private Panel panel4;
        private Label label6;
        private Label label7;
        private TextBox txtquantidade;
        private Label label8;
        private Label label9;
        private Label label12;
        private Button btnexcluiritem;
        private Button btnlocalizar;
        private Button btneditaritem;
        private Button btnnovoitem;
        private TextBox txtvalor;
        private TextBox txttotal;
        private Label label1;
        private Button btnatualizarpedido;
        private Button btnnovopedido;
        private TextBox txtestoque;
        private TextBox txtidproduto;
        private Label label2;
        private Label label3;
        private DataGridView dgvpedido;
        private Button btnfinalizarvenda;
        private Button btnfinalizarpedido;
        private ComboBox cbxproduto;
        private ComboBox cbxcliente;
    }
}